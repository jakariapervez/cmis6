﻿namespace TitleBlocks
{
    public class A0TitleBlock : TBlock
    {
        public int Height { get; set; }
        public int Width { get; set; }

        public A0TitleBlock()
        {
            Height = 841;
            Width = 1189;
        }
    }
}
