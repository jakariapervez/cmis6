﻿namespace TitleBlocks
{
    public class A1TitleBlock : TBlock
    {
        public int Height { get; set; }
        public int Width { get; set; }

        public A1TitleBlock()
        {
            Height = 594;
            Width = 841;
        }
    }
}
