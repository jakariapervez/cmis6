﻿namespace TitleBlocks
{
    public class A2TitleBlock : TBlock
    {
        public int Height { get; set; }
        public int Width { get; set; }

        public A2TitleBlock()
        {
            Height = 420;
            Width = 594;
        }
    }
}
