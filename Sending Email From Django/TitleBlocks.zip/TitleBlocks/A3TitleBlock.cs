﻿namespace TitleBlocks
{
    public class A3TitleBlock : TBlock
    {
        public int Height { get; set; }
        public int Width { get; set; }

        public A3TitleBlock()
        {
            Height = 297;
            Width = 420;
        }
    }
}
