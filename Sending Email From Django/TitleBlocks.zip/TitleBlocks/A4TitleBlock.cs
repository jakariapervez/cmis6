﻿namespace TitleBlocks
{
    public class A4TitleBlock : TBlock
    {
        public int Height { get; set; }
        public int Width { get; set; }

        public A4TitleBlock()
        {
            Height = 210;
            Width = 297;
        }
    }
}
