<?php include('includes/header.php'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="card card-map">
			<div class="header">
                <h4 class="title">Google Maps</h4>
                <p class="category">24 Hours performance</p>
            </div>
			<div class="content">
				<p> here is sample card</p>
			</div>
		</div>
	</div>
</div>

<?php include('includes/footer.php'); ?>